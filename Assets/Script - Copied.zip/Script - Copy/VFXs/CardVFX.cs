﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class CardVFX : MonoBehaviour
{
    [Header("Glow")]
    public Image glowImage;

    [Header("Shimmer")]
    public Image shimmerImage;

    [Header("Hint Settings")]
    public float hintDelay = 10f;

    private Coroutine glowCoroutine;
    private Coroutine shimmerCoroutine;
    private Coroutine hintCoroutine;
    private bool isPlayable = false;

    void Start()
    {
        ResetGlow();
        ResetShimmer();
    }

    void ResetGlow()
    {
        if (glowImage != null)
        {
            Color c = glowImage.color;
            c.a = 0f;
            glowImage.color = c;
            glowImage.raycastTarget = false;
        }
    }

    void ResetShimmer()
    {
        if (shimmerImage != null)
        {
            Color c = shimmerImage.color;
            c.a = 0f;
            shimmerImage.color = c;
            shimmerImage.raycastTarget = false;
        }
    }

    // ── Playable Glow ─────────────────────────────────

    public void SetPlayable(bool playable)
    {
        isPlayable = playable;

        if (glowCoroutine != null)
            StopCoroutine(glowCoroutine);

        if (hintCoroutine != null)
            StopCoroutine(hintCoroutine);

        if (playable)
        {
            // Start hint glow after delay
            hintCoroutine = StartCoroutine(
                StartHintAfterDelay());
        }
        else
        {
            // Immediately fade out glow
            glowCoroutine = StartCoroutine(FadeGlow(0f));
        }
    }

    IEnumerator StartHintAfterDelay()
    {
        yield return new WaitForSeconds(hintDelay);

        // Show glow if card is still playable
        if (isPlayable)
            glowCoroutine = StartCoroutine(PulseGlow());
    }

    IEnumerator PulseGlow()
    {
        if (glowImage == null) yield break;

        while (isPlayable)
        {
            // Fade in
            float elapsed = 0f;
            while (elapsed < 0.5f)
            {
                if (!isPlayable) break;
                elapsed += Time.deltaTime;
                Color c = glowImage.color;
                c.a = Mathf.Lerp(0f, 0.85f, elapsed / 0.5f);
                glowImage.color = c;
                yield return null;
            }

            yield return new WaitForSeconds(0.2f);

            // Fade out
            elapsed = 0f;
            while (elapsed < 0.5f)
            {
                if (!isPlayable) break;
                elapsed += Time.deltaTime;
                Color c = glowImage.color;
                c.a = Mathf.Lerp(0.85f, 0.1f, elapsed / 0.5f);
                glowImage.color = c;
                yield return null;
            }

            yield return new WaitForSeconds(0.2f);
        }

        // Fade out completely when done
        yield return StartCoroutine(FadeGlow(0f));
    }

    IEnumerator FadeGlow(float targetAlpha)
    {
        if (glowImage == null) yield break;

        float startAlpha = glowImage.color.a;
        float elapsed = 0f;

        while (elapsed < 0.3f)
        {
            elapsed += Time.deltaTime;
            Color c = glowImage.color;
            c.a = Mathf.Lerp(startAlpha,
                targetAlpha, elapsed / 0.3f);
            glowImage.color = c;
            yield return null;
        }

        Color final = glowImage.color;
        final.a = targetAlpha;
        glowImage.color = final;
    }

    // ── Shimmer ───────────────────────────────────────

    public void PlayShimmer()
    {
        if (shimmerCoroutine != null)
            StopCoroutine(shimmerCoroutine);
        shimmerCoroutine = StartCoroutine(DoShimmer());
    }

    IEnumerator DoShimmer()
    {
        if (shimmerImage == null) yield break;

        RectTransform rt =
            shimmerImage.GetComponent<RectTransform>();
        if (rt != null)
            rt.anchoredPosition = new Vector2(-100f, 0f);

        float elapsed = 0f;
        float duration = 0.4f;

        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = elapsed / duration;

            Color c = shimmerImage.color;
            c.a = t < 0.5f ?
                Mathf.Lerp(0f, 0.6f, t * 2f) :
                Mathf.Lerp(0.6f, 0f, (t - 0.5f) * 2f);
            shimmerImage.color = c;

            if (rt != null)
                rt.anchoredPosition = new Vector2(
                    Mathf.Lerp(-100f, 100f, t), 0f);

            yield return null;
        }

        ResetShimmer();
    }

    // ── Reset All ─────────────────────────────────────

    public void ResetAll()
    {
        isPlayable = false;

        if (glowCoroutine != null)
            StopCoroutine(glowCoroutine);
        if (hintCoroutine != null)
            StopCoroutine(hintCoroutine);
        if (shimmerCoroutine != null)
            StopCoroutine(shimmerCoroutine);

        ResetGlow();
        ResetShimmer();
    }
}