using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using Debug = UnityEngine.Debug;
using Random = UnityEngine.Random;

public class OpponentAI : MonoBehaviour
{
    [Header("Difficulty")]
    public GameSettings.Difficulty difficulty =
        GameSettings.Difficulty.Medium;

    private List<Card> opponentCards = new List<Card>();

    void Start()
    {
        if (GameSettings.Instance != null)
        {
            difficulty = GameSettings.Instance.selectedDifficulty;
            Debug.Log("AI Difficulty: " + difficulty);
        }
    }

    public void SetCards(List<Card> cards)
    {
        opponentCards = new List<Card>(cards);
        Debug.Log("AI received " + opponentCards.Count + " cards");
    }

    public void AddCardToHand(Card card)
    {
        opponentCards.Add(card);
        Debug.Log("AI drew a card. Total: " + opponentCards.Count);
    }

    public void RemoveCardFromHand(Card card)
    {
        opponentCards.Remove(card);
        Debug.Log("AI played a card. Total: " + opponentCards.Count);
    }

    public void StartOpponentTurn()
    {
        Debug.Log("Opponent thinking... (" + difficulty + ")");
        StartCoroutine(ThinkAndPlay());
    }

    IEnumerator ThinkAndPlay()
    {
        float thinkTime = GetThinkTime();
        yield return new WaitForSeconds(thinkTime);

        if (GameSetup.Instance.GetPlayerCardCount() == 0)
        {
            WinLoseManager.Instance?.PlayerLoses();
            yield break;
        }

        Card topCard = GameManager.Instance.topCardOnDiscardPile;
        List<Card> playableCards = GetPlayableCards(topCard);

        Debug.Log("AI has " + opponentCards.Count +
            " cards. Playable: " + playableCards.Count);

        if (playableCards.Count > 0)
        {
            if (difficulty == GameSettings.Difficulty.Easy)
            {
                // Easy AI skips turn 30% of the time
                // even if it has playable cards
                if (Random.Range(0f, 1f) < 0.3f)
                {
                    Debug.Log("Easy AI skips turn!");
                    GameSetup.Instance.AddCardToOpponent();
                    yield return new WaitForSeconds(0.5f);
                    GameManager.Instance.GivePlayerTurn();
                    yield break;
                }

                // Try to get a number card to play
                Card easyCard = SelectEasyCard(playableCards);

                if (easyCard != null)
                {
                    PlayCard(easyCard);
                }
                else
                {
                    // No number cards � 60% chance to draw
                    // instead of playing special
                    if (Random.Range(0f, 1f) < 0.6f)
                    {
                        Debug.Log("Easy AI avoids special � draws!");
                        GameSetup.Instance.AddCardToOpponent();
                        yield return new WaitForSeconds(0.5f);
                        GameManager.Instance.GivePlayerTurn();
                    }
                    else
                    {
                        // Play weakest special available
                        CardType[] weakFirst = {
                        CardType.Reverse,
                        CardType.Block,
                        CardType.DrawTwo,
                        CardType.RollDice,
                        CardType.DrawFour
                    };

                        Card weakCard = null;
                        foreach (CardType type in weakFirst)
                        {
                            foreach (Card card in playableCards)
                            {
                                if (card.type == type)
                                {
                                    weakCard = card;
                                    break;
                                }
                            }
                            if (weakCard != null) break;
                        }

                        if (weakCard != null)
                            PlayCard(weakCard);
                        else
                            PlayCard(playableCards[
                                Random.Range(0, playableCards.Count)]);
                    }
                }
            }
            else
            {
                Card cardToPlay = SelectCard(playableCards, topCard);
                PlayCard(cardToPlay);
            }
        }
        else
        {
            Debug.Log("AI has no playable card � drawing!");
            GameSetup.Instance.AddCardToOpponent();

            yield return new WaitForSeconds(0.5f);

            Card topCardNow =
                GameManager.Instance.topCardOnDiscardPile;
            List<Card> newPlayable = GetPlayableCards(topCardNow);

            if (newPlayable.Count > 0)
            {
                bool shouldPlay = false;

                if (difficulty == GameSettings.Difficulty.Hard)
                    shouldPlay = true;
                else if (difficulty == GameSettings.Difficulty.Medium)
                    shouldPlay = Random.Range(0f, 1f) < 0.4f;
                // Easy NEVER plays drawn card

                if (shouldPlay)
                    PlayCard(SelectCard(newPlayable, topCardNow));
                else
                    GameManager.Instance.GivePlayerTurn();
            }
            else
            {
                GameManager.Instance.GivePlayerTurn();
            }
        }
    }

    float GetThinkTime()
    {
        switch (difficulty)
        {
            case GameSettings.Difficulty.Easy:
                // Slow think time � feels less threatening
                return Random.Range(2f, 3.5f);
            case GameSettings.Difficulty.Medium:
                return Random.Range(1f, 2f);
            case GameSettings.Difficulty.Hard:
                return Random.Range(0.8f, 1.5f);
            default: return 1.5f;
        }
    }

    List<Card> GetPlayableCards(Card topCard)
    {
        List<Card> playable = new List<Card>();
        if (topCard == null)
        {
            playable.AddRange(opponentCards);
            return playable;
        }

        foreach (Card card in opponentCards)
        {
            if (GameManager.Instance.IsMoveLegal(card))
                playable.Add(card);
        }
        return playable;
    }

    Card SelectCard(List<Card> playable, Card topCard)
    {
        switch (difficulty)
        {
            case GameSettings.Difficulty.Easy:
                return SelectEasyCard(playable);
            case GameSettings.Difficulty.Medium:
                return SelectMediumCard(playable);
            case GameSettings.Difficulty.Hard:
                return SelectHardCard(playable);
            default:
                return playable[Random.Range(0, playable.Count)];
        }
    }

    Card SelectEasyCard(List<Card> playable)
    {
        // Easy AI NEVER plays special cards � number cards only
        List<Card> numbers = new List<Card>();

        foreach (Card c in playable)
            if (c.type == CardType.Number) numbers.Add(c);

        // Always play number card if available
        if (numbers.Count > 0)
            return numbers[Random.Range(0, numbers.Count)];

        // If FORCED to play special � only play weakest
        // and only 40% of the time otherwise draws instead
        return null;
    }

    Card SelectMediumCard(List<Card> playable)
    {
        // 70% prefer number cards
        List<Card> numbers = new List<Card>();
        List<Card> specials = new List<Card>();

        foreach (Card c in playable)
        {
            if (c.type == CardType.Number) numbers.Add(c);
            else specials.Add(c);
        }

        if (numbers.Count > 0 && Random.Range(0f, 1f) < 0.7f)
            return numbers[Random.Range(0, numbers.Count)];

        if (specials.Count > 0)
            return specials[Random.Range(0, specials.Count)];

        return playable[Random.Range(0, playable.Count)];
    }

    Card SelectHardCard(List<Card> playable)
    {
        // Priority: DrawFour > RollDice > DrawTwo > Block > Reverse > Number
        CardType[] priority = {
            CardType.DrawFour,
            CardType.RollDice,
            CardType.DrawTwo,
            CardType.Block,
            CardType.Reverse,
            CardType.Number
        };

        foreach (CardType type in priority)
        {
            foreach (Card card in playable)
            {
                if (card.type == type) return card;
            }
        }

        return playable[0];
    }

    void PlayCard(Card card)
    {
        Debug.Log("AI plays: " + card.cardName);
        StartCoroutine(PlayCardWithAnimation(card));
    }

    IEnumerator PlayCardWithAnimation(Card card)
    {
        GameObject cardToAnimate = null;
        if (GameSetup.Instance.opponentCards.Count > 0)
            cardToAnimate = GameSetup.Instance.opponentCards
                [GameSetup.Instance.opponentCards.Count - 1];

        if (cardToAnimate != null)
        {
            // Flip to front face before animating
            UnityEngine.UI.Image cardImage =
                cardToAnimate.GetComponent<UnityEngine.UI.Image>();
            if (cardImage != null && card.cardSprite != null)
                cardImage.sprite = card.cardSprite;

            CardAnimator anim =
                cardToAnimate.GetComponent<CardAnimator>();
            RectTransform discardRect =
                GameSetup.Instance.discardPileImage
                    .GetComponent<RectTransform>();

            if (anim != null && discardRect != null)
            {
                bool animDone = false;
                StartCoroutine(anim.PlayAnimation(
                    discardRect, () => animDone = true));
                yield return new WaitUntil(() => animDone);
            }

            Destroy(cardToAnimate);
        }

        GameManager.Instance.topCardOnDiscardPile = card;
        if (GameSetup.Instance.discardPileImage != null &&
            card.cardSprite != null)
            GameSetup.Instance.discardPileImage.sprite =
                card.cardSprite;

        RemoveCardFromHand(card);
        GameSetup.Instance.RemoveOpponentCardByData(card);
        GameManager.Instance.opponentHandCount--;

        if (opponentCards.Count == 0)
        {
            Debug.Log("Opponent wins!");
            WinLoseManager.Instance?.PlayerLoses();
            yield break;
        }

        if (opponentCards.Count == 1)
            Debug.Log("Opponent Fatebound!");

        HandleSpecialCard(card);
    }

    void HandleSpecialCard(Card card)
    {
        // ALWAYS pass false here � opponent played the card
        // so the effect text must say "You draw..." etc.
        CardEffectAnimator.Instance?.ShowEffect(card.type, false);

        switch (card.type)
        {
            case CardType.Number:
                GameManager.Instance.GivePlayerTurn();
                break;

            case CardType.Block:
            case CardType.Reverse:
                Debug.Log("AI Block/Reverse � player skips!");
                GameManager.Instance.isPlayerTurn = false;
                Invoke("StartOpponentTurn", 2f);
                break;

            case CardType.DrawTwo:
                Debug.Log("AI Draw Two � player draws 2!");
                GameSetup.Instance.AddCardToPlayer();
                GameSetup.Instance.AddCardToPlayer();
                GameManager.Instance.playerHandCount += 2;
                GameManager.Instance.isPlayerTurn = false;
                Invoke("StartOpponentTurn", 2f);
                break;

            case CardType.DrawFour:
                Debug.Log("AI Draw Four � player draws 4!");
                for (int i = 0; i < 4; i++)
                    GameSetup.Instance.AddCardToPlayer();
                GameManager.Instance.playerHandCount += 4;
                GameManager.Instance.isPlayerTurn = false;
                Invoke("StartOpponentTurn", 2f);
                break;

            case CardType.RollDice:
                Debug.Log("AI Roll Dice!");
                DiceManager.Instance?.RollDice((result) =>
                {
                    Debug.Log("AI dice: " + result +
                        " � player draws " + result);
                    for (int i = 0; i < result; i++)
                        GameSetup.Instance.AddCardToPlayer();
                    GameManager.Instance.playerHandCount +=
                        result;
                    GameManager.Instance.isPlayerTurn = false;
                    Invoke("StartOpponentTurn", 2f);
                });
                break;
        }
    }
}